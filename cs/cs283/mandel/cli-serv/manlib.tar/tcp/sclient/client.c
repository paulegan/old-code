/*
 * client.c
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <sltcp.h>
#define SERVER "security"

int conn;
void my_read(int);
void user_read(int, char *, int);

void main(void)
{
	if((conn = conn_open(SERVER, 13666)) < 0)
	{
		slperror("conn_open");
		exit(1);
	}

	/*
	 * Whenever a complete data structure is read, call the routine
	 * user_read(), passing the complete data structure as an argument.
	 */

	if(conn_register(user_read, IO_READ) < 0)
	{
		slperror("conn_register");
		exit(1);
	}


	/*
	 * Whenever data is available on file descriptor 0, call the routine
	 * my_read().
	 */

	if(conn_addfd(my_read, 0, CONN_FD_READ) < 0)
	{
		slperror("conn_addfd");
		exit(1);
	}

	/*
	 * Now enter the event loop.
	 */

	sl_event_loop(); 
}

/*
 * The routine called whenever their is a complete data structure ready
 * on a particular connection.
 */

void user_read(int c, char *buf, int len)
{
	printf("%s\nlen = %d\n",buf,strlen(buf));
}

/*
 * The routine called whenever there is data available for reading on
 * file descriptor 0. This reads what the user has typed and sends it
 * down the connection to the server.
 */

void my_read(int c)
{
	char ch[1024];

	fgets(ch, 1024, stdin);
	if(feof(stdin))
	{
		conn_close(conn);
		exit(0);
	}
	if(ch[strlen(ch) - 1] == '\n')
	{
		ch[strlen(ch) - 1] = '\0';
	}
	if(conn_write(conn, ch, strlen(ch)) < 0)
	{
		slperror("conn_write");
		exit(1);
	}
}

